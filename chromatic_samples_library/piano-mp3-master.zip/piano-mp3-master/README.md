# Piano MP3

This is a repo for holding MP3 files for an acoustic piano, sampled directly from this [repo](https://github.com/gleitz/midi-js-soundfonts). These are exposed for use in another repo. The `/example` is a good show of what this repo can/will be used for.

## Setting up `/example`.

* `yarn && yarn start`
* visit `http://localhost:3000/example`
